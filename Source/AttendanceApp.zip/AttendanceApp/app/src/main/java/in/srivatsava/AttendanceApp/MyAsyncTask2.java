package in.srivatsava.AttendanceApp;

import android.os.AsyncTask;

import java.util.ArrayList;

public class MyAsyncTask2 extends AsyncTask<String, Void, ArrayList<MyTuple>> {
    DatabaseAccess ob = new DatabaseAccess();
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected ArrayList<MyTuple> doInBackground(String... username) {

        ArrayList<MyTuple> arrayList = new ArrayList<MyTuple>(  );
        try {
            arrayList = ob.getAttendance( username[0], username[1] );
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    @Override
    protected void onPostExecute(ArrayList<MyTuple> result) {
        super.onPostExecute(result);
    }
}