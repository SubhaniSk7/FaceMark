package in.srivatsava.AttendanceApp.ui.report;

import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import in.srivatsava.AttendanceApp.MyAdapter;
import in.srivatsava.AttendanceApp.MyAsyncTask2;
import in.srivatsava.AttendanceApp.MyTuple;
import in.srivatsava.AttendanceApp.R;

public class ReportFragment extends Fragment {
    String setCourseName;
    private ReportViewModel mViewModel;
    RecyclerView recyclerView;
    public static ReportFragment newInstance() {
        return new ReportFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate( R.layout.report_fragment, container, false );

        recyclerView = (RecyclerView) root.findViewById( R.id.myRecycler );
        Bundle arguments = getArguments();
        setCourseName = arguments.getString("course_name");
        ArrayList<MyTuple> arrayList = new ArrayList<MyTuple>();
        try {
            arrayList = new MyAsyncTask2().execute(getActivity().getIntent().getStringExtra( "email" ), setCourseName).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        String[] languages = {"A", "B", "C","D","E","F","G","H","I","J","K","L","M","N","O"};
        int[] status = {1,0,1,0,0,0,1,0,1,1,0,1,1,1,1};
        for(int i=0;i<arrayList.size();i++){
            languages[i] = arrayList.get(i).getEmail();
            status[i] = arrayList.get(i).getStatus();
        }

        recyclerView.setLayoutManager( new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter( new MyAdapter( languages, status ) );

        return root;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated( savedInstanceState );
        mViewModel = ViewModelProviders.of( this ).get( ReportViewModel.class );
        // TODO: Use the ViewModel
    }

}
