package in.srivatsava.AttendanceApp.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProviders;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import in.srivatsava.AttendanceApp.MyAsyncTask;
import in.srivatsava.AttendanceApp.MyAsyncTask2;
import in.srivatsava.AttendanceApp.MyTuple;
import in.srivatsava.AttendanceApp.R;
import in.srivatsava.AttendanceApp.ui.target.TargetFragment;

public class HomeFragment extends Fragment implements View.OnClickListener {
    private CardView[] cards = new CardView[3];
    View root;
    private String courseName;
    int percentage[] = new int[3];
    private int[] cardIds = new int[] {R.id.card_1, R.id.card_2, R.id.card_3};
    private TextView[] tv = new TextView[3];
    private TextView[] tvPv = new TextView[3];
    private int[] tvIds = new int[] {R.id.tv_cv1, R.id.tv_cv2, R.id.tv_cv3};
    private int[] tvPvIds = new int[] {R.id.tv_pv1, R.id.tv_pv2, R.id.tv_pv3};
    private ViewGroup viewGroup;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel = ViewModelProviders.of( this ).get( HomeViewModel.class );
        root = inflater.inflate(R.layout.fragment_home, container, false);

        ArrayList<String> arrayList = new ArrayList<String>();
        try {
            arrayList = new MyAsyncTask().execute(getActivity().getIntent().getStringExtra( "email" )).get();
        }
        catch (Exception e){
            e.printStackTrace();
        }

        ArrayList<MyTuple> arrayList2 = new ArrayList<MyTuple>();
        for (int i=0;i<arrayList.size();i++){
            try {
                arrayList2 = new MyAsyncTask2().execute(getActivity().getIntent().getStringExtra( "email" ), arrayList.get(i)).get();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            String[] languages = {"A", "B", "C","D","E","F","G","H","I","J","K","L","M","N","O"};
            int[] status = {1,0,1,0,0,0,1,0,1,1,0,1,1,1,1};
            int count = 0;
            for(int j=0;j<arrayList2.size();j++){
                languages[j] = arrayList2.get(j).getEmail();
                status[j] = arrayList2.get(j).getStatus();
                if (status[j] == 1)
                    count++;
                percentage[i] = (int)(count*100/arrayList2.size());
                }

            }

        for (int i=0;i<arrayList.size();i++){
            cards[i] = (CardView) root.findViewById( cardIds[i] );
            cards[i].setOnClickListener( (View.OnClickListener) this );
            cards[i].setVisibility( View.VISIBLE );
            tv[i] = (TextView) root.findViewById( tvIds[i] );
            tv[i].setText( arrayList.get(i) );
            tvPv[i] = (TextView) root.findViewById( tvPvIds[i] );
            tvPv[i].setText( String.valueOf( percentage[i])+"%" );
        }

        return root;
    }

    public void onClick(View view){
        TextView x;
        Fragment fragment = new TargetFragment();
        switch (view.getId()){
            case (R.id.card_1):
                x = (TextView) root.findViewById( R.id.tv_cv1 );
                replaceFragment( fragment, x.getText().toString() );
                break;
            case (R.id.card_2):
                x = (TextView) root.findViewById( R.id.tv_cv2 );
                replaceFragment( fragment, x.getText().toString() );
                break;
            case (R.id.card_3):
                x = (TextView) root.findViewById( R.id.tv_cv3 );
                replaceFragment( fragment, x.getText().toString() );
                break;
        }

    }

    private void replaceFragment(Fragment fragment, String course) {
        Bundle arguments = new Bundle();
        arguments.putString( "course_name" , course);
        fragment.setArguments(arguments);
        FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_left);
        transaction.replace(R.id.nav_host_fragment, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }
}