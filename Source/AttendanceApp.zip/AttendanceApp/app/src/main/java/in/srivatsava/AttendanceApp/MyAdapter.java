package in.srivatsava.AttendanceApp;

import android.media.Image;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private String[] data;
    private int[] status;
    public MyAdapter(String[] data, int[] status){
        this.data = data;
        this.status = status;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate( R.layout.list_item_layout, parent, false );
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        String title = data[position];
        int status_ = status[position];
        holder.textView.setText(title);
        if (status_ == 1){
            holder.imageView.setImageResource( R.drawable.ic_check_black_24dp );
        }

    }

    @Override
    public int getItemCount() {
        return data.length;
    }

    public class MyViewHolder  extends RecyclerView.ViewHolder{
        ImageView imageView;
        TextView textView;
        public MyViewHolder(View itemView){
            super(itemView);
            imageView = itemView.findViewById(R.id.imgIcon);
            textView = itemView.findViewById( R.id.txtDate );
        }
    }
}
