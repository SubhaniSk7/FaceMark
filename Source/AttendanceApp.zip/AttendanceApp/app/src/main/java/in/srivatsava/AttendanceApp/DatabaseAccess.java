package in.srivatsava.AttendanceApp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class DatabaseAccess {
    public ArrayList<String> getCourses(String username) throws Exception {
        StringBuffer responseContent = new StringBuffer();
        BufferedReader reader;
        JSONObject jsonObject = null;
        String line;
        try{
            URL url = new URL("http://192.168.165.27:5000/db/getCourses/"+username);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            int status = conn.getResponseCode();
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while((line = reader.readLine()) != null){
                responseContent.append(line);
            }
            reader.close();
            jsonObject = new JSONObject(responseContent.toString());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        ArrayList<String> arrayList = new ArrayList<String>(  );
        JSONArray jArray = jsonObject.getJSONArray("message");
        if (jArray != null) {
            for (int i=0;i<jArray.length();i++){
                arrayList.add(jArray.getString(i));
            }
        }
        return arrayList;
    }


    public ArrayList<MyTuple> getAttendance(String username, String course_name) throws Exception {
        StringBuffer responseContent2 = new StringBuffer();
        BufferedReader reader;
        JSONObject jsonObject = null;
        String line;
        String old_url = "";
        String new_url = "";
        try{
            old_url = "http://192.168.165.27:5000/db/getAttendance/"+username+"/"+course_name;
            new_url = old_url.replaceAll(" ", "%20");
            URL url = new URL(new_url);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            int status = conn.getResponseCode();
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            while((line = reader.readLine()) != null){
                responseContent2.append(line);
            }
            reader.close();
            jsonObject = new JSONObject(responseContent2.toString());
        }
        catch(Exception e){
            e.printStackTrace();
        }
        ArrayList<MyTuple> arrayList = new ArrayList<MyTuple>(  );
        JSONArray jArray1 = jsonObject.getJSONArray("message1");
        JSONArray jArray2 = jsonObject.getJSONArray("message2");
        if (jArray1 != null) {
            for (int i=0;i<jArray1.length();i++){
                arrayList.add(new MyTuple( jArray1.getString(i), jArray2.getInt(i) ));
            }
        }
        return arrayList;
    }
}


