package in.srivatsava.AttendanceApp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class MainActivity extends AppCompatActivity {

    final static int GOOGLE_SIGN_IN = 123;

    FirebaseAuth mAuth;
    Button btn_login, btn_logout;
    TextView textView;
    ImageView imageView;
    ProgressBar progressBar;
    GoogleSignInClient mGoogleSignInClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_login = (Button) findViewById(R.id.login);
        btn_logout = (Button) findViewById(R.id.logout);
        textView = (TextView) findViewById(R.id.text);
        imageView = (ImageView) findViewById(R.id.image);
        progressBar = (ProgressBar) findViewById(R.id.progress_circular);

        mAuth = FirebaseAuth.getInstance();

        GoogleSignInOptions googleSignInOptions = new GoogleSignInOptions
                .Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, googleSignInOptions);

        btn_login.setOnClickListener(v -> SignInGoogle());
        btn_logout.setOnClickListener(v -> Logout());

        if(mAuth.getCurrentUser() != null) {
            FirebaseUser firebaseUser = mAuth.getCurrentUser();
            updateUI(firebaseUser);
        }
    }

    void SignInGoogle(){
        progressBar.setVisibility(View.VISIBLE);
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, GOOGLE_SIGN_IN);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == GOOGLE_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn
                    .getSignedInAccountFromIntent(data);

            try{
                GoogleSignInAccount account = task.getResult(ApiException.class);
                if (account != null) {
                    firebaseAuthWithGoogle(account);
                }

            } catch (ApiException e) { e.printStackTrace(); }
        }

    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount account) {
        Log.d("TAG", "firebaseAuthWithGoogle: " + account.getId());
        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if(task.isSuccessful()){
                        progressBar.setVisibility(View.INVISIBLE);
                        Log.d("TAG", "Signin successful");
                        FirebaseUser firebaseUser = mAuth.getCurrentUser();
                        updateUI(firebaseUser);
                    }
                    else {
                        progressBar.setVisibility(View.INVISIBLE);
                        Log.w("TAG", "Signin Failure", task.getException());
                        Toast.makeText(this, "Authentication Failed", Toast.LENGTH_SHORT).show();
                        updateUI(null);
                    }
                });
    }

    private void updateUI(FirebaseUser firebaseUser) {
        if (firebaseUser != null){
            String name = firebaseUser.getDisplayName();
            String email = firebaseUser.getEmail();
//            String displayText = "Welcome\n"+name+"\n"+email;
//            textView.setText(displayText);
//            Picasso.get().setLoggingEnabled(true);
//            Picasso.get().load(R.mipmap.ic_iiitd_foreground)
//                    .resize(100,100)
//                    .placeholder(R.mipmap.ic_iiitd_foreground)
//                    .into(imageView);
//            btn_login.setVisibility(View.INVISIBLE);
//            btn_logout.setVisibility(View.VISIBLE);
            Intent intent;
            if (email.equals( "lkesanupalli18054@iiitd.ac.in" )) {
                intent = new Intent( MainActivity.this, TeachersActivity.class );
                intent.putExtra("username", "Chinnu");
                intent.putExtra("email", email);
                startActivity(intent);
                finish();
            }
            else{
                intent = new Intent( MainActivity.this, StudentsActivity.class );
                intent.putExtra("username", name);
                intent.putExtra("email", email);
                startActivity(intent);
                finish();
            }
        }
        else{
            textView.setText(getString(R.string.app_name));
            Picasso.get().setLoggingEnabled(true);
            Picasso.get().load(R.mipmap.ic_iiitd_foreground)
                    .resize(100,100)
                    .placeholder(R.mipmap.ic_iiitd_foreground)
                    .into(imageView);
            btn_login.setVisibility(View.VISIBLE);
            btn_logout.setVisibility(View.INVISIBLE);

        }
    }

    public void Logout() {
        FirebaseAuth.getInstance().signOut();
        mGoogleSignInClient.signOut().addOnCompleteListener(this, task -> updateUI(null));
    }
}
