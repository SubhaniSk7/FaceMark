package in.srivatsava.AttendanceApp;

public class MyTuple{
    String email = "";
    int status = 0;
    public MyTuple(String email, int status){
        this.email = email;
        this.status = status;
    }

    public String getEmail(){
        return email;
    }

    public int getStatus(){
        return status;
    }
}