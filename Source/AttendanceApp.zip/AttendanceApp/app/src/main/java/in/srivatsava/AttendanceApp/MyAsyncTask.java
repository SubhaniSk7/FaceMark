package in.srivatsava.AttendanceApp;

import android.os.AsyncTask;

import java.util.ArrayList;

public class MyAsyncTask extends AsyncTask<String, Void, ArrayList<String>> {
    DatabaseAccess ob = new DatabaseAccess();
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected ArrayList<String> doInBackground(String... username) {

        ArrayList<String> arrayList = new ArrayList<String>(  );
        try {
            arrayList = ob.getCourses( username[0] );
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arrayList;
    }

    @Override
    protected void onPostExecute(ArrayList<String> result) {
        super.onPostExecute(result);
    }
}