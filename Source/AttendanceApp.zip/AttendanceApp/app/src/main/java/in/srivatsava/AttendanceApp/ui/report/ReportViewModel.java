package in.srivatsava.AttendanceApp.ui.report;

import androidx.lifecycle.ViewModel;

public class ReportViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
